﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_III
{
    class Program
    {
        static void Main()
        {
            int[] numeros = { 10, 20, 30, 40, 50 };
            int resultado = 0;
            int divisor = 1;

            if (numeros.Length > 0)
            {
                Console.WriteLine("Último número en la lista: " + numeros[numeros.Length - 1]);
            }
            else
            {
                Console.WriteLine("El array está vacío.");
            }

            for (int i = 0; i < numeros.Length; i++)
            {
                resultado += numeros[i] / divisor;
                Debug.WriteLine($"Resultado parcial en la iteración {i}: {resultado}");
            }

            Debug.WriteLine("Resultado después del bucle: " + resultado);
            Console.WriteLine("Proceso finalizado.");
        }
    }
}
