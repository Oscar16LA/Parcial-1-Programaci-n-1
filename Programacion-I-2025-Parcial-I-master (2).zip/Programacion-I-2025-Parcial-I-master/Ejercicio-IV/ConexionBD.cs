﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Data.SqlClient;

namespace Ejercicio_IV
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Server=.\\SQLEXPRESS;Database=Escuela;Trusted_Connection=True;";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    Console.WriteLine("Conexión exitosa a la base de datos.");

                    string query = "SELECT * FROM Estudiantes WHERE Edad > @Edad";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        Console.Write("Ingrese la edad mínima: ");
                        int edadMinima = int.Parse(Console.ReadLine());
                        cmd.Parameters.AddWithValue("@Edad", edadMinima);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine($"Nombre: {reader["Nombre"]}, Edad: {reader["Edad"]}");
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Error en la conexión a la base de datos: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Se produjo un error: " + ex.Message);
            }
            finally
            {
                Console.WriteLine("Proceso de conexión finalizado.");
            }
        }
    }
}
