﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_I
{
    class Persona
    {
        private string nombre;
        private int edad;

        public Persona(string nombrePersona, int edadPersona)
        {
            this.nombre = nombrePersona;
            this.edad = edadPersona;
        }

        public void MostrarDetalles()
        {
            Console.WriteLine($"Nombre: {nombre}, Edad: {edad}");
        }
    }

    class Program
    {
        static void Main()
        {
            Persona persona1 = new Persona("Carlos", 25);
            persona1.MostrarDetalles();
        }
    }
}